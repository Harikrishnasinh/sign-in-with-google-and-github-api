const mongoose = require("mongoose");

const DB =
  "mongodb+srv://google-auth:google-auth@google-auth.f0t5p8h.mongodb.net/";

mongoose
  .connect(DB, {
    useUnifiedTopology: true,
    useNewUrlParser: true,
  })
  .then(() => console.log("database connected"))
  .catch((err) => console.log("errr", err));
