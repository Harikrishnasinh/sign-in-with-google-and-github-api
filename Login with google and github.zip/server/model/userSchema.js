const mongoose = require("mongoose");

// const provider =
const userSchema = new mongoose.Schema(
  {
    provider: {
      type: String,
      enum: ["google", "github", "email"],
      default: "email",
    },
    googleId: String,
    displayName: String,
    email: String,
    image: String,
  },
  { timestamps: true }
);

const userdb = new mongoose.model("users", userSchema);

module.exports = userdb;
